#!/usr/bin/env node
const crypto = require('crypto');
const fs = require('fs');

// Drei User für novaesecret.com
const users = [
  { username: 'hieu', password: 'Novae!Boss-2611' },
  { username: 'richiee', password: 'Novae!Pack-7439' },
  { username: 'armando', password: 'Novae!Lager-5182' }
];

// Master key für Snapshot-Verschlüsselung
const masterKey = crypto.randomBytes(32);

// Gate-Daten generieren
const gateUsers = users.map(u => {
  const salt = crypto.randomBytes(16);
  const userPw = u.username + ':' + u.password;

  // PBKDF2: 310.000 Iterationen, SHA-256
  const keyEncKey = crypto.pbkdf2Sync(userPw, salt, 310000, 32, 'sha256');

  // Verschlüssele den Master-Key mit AES-256-GCM
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', keyEncKey, iv);
  const enc = cipher.update(masterKey);
  cipher.final();
  const authTag = cipher.getAuthTag();

  return {
    u: u.username,
    s: salt.toString('base64'),
    i: iv.toString('base64'),
    w: Buffer.concat([enc, authTag]).toString('base64')
  };
});

// Snapshot-Daten (leerer Platzhalter)
const snapshot = {
  ts: new Date().toISOString(),
  data: { orders: [], products: [], countries: [], carts: [] }
};

// Verschlüssele Snapshot mit Master-Key
const snapIv = crypto.randomBytes(12);
const snapCipher = crypto.createCipheriv('aes-256-gcm', masterKey, snapIv);
const snapEnc = snapCipher.update(JSON.stringify(snapshot), 'utf8');
snapCipher.final();
const snapAuthTag = snapCipher.getAuthTag();

const encSnap = {
  i: snapIv.toString('base64'),
  d: Buffer.concat([snapEnc, snapAuthTag]).toString('base64')
};

const gateJson = {
  users: gateUsers,
  snap: encSnap,
  mk: masterKey.toString('base64')
};

console.log(JSON.stringify(gateJson, null, 2));
fs.writeFileSync('/root/novae-deploy/gate.json', JSON.stringify(gateJson));
console.log('\n✅ gate.json erstellt');
